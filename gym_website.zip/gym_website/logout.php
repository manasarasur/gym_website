<?php
session_start();
include 'db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['login'])) {
        // Handle login
        $username = $_POST['username'];
        $password = $_POST['password'];

        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            header("Location: index.php"); // Redirect to home page after login
            exit();
        } else {
            $error = "Invalid username or password.";
        }
    } elseif (isset($_POST['register'])) {
        // Handle registration
        $username = $_POST['reg_username'];
        $password = password_hash($_POST['reg_password'], PASSWORD_DEFAULT);
        $email = $_POST['reg_email'];

        // Check if username or email already exists
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->execute([$username, $email]);
        if ($stmt->rowCount() > 0) {
            $error = "Username or email already exists.";
        } else {
            $stmt = $pdo->prepare("INSERT INTO users (username, password, email) VALUES (?, ?, ?)");
            $stmt->execute([$username, $password, $email]);
            $success = "Registration successful! You can now log in.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login / Sign Up</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #F4F4F4; /* Light gray */
            margin: 0;
            padding: 0;
        }
        header {
            background-color: rgb(67, 133, 105); /* Main header color */
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        nav ul li {
            display: inline;
            margin: 0 15px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        .login-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff; /* White background for the form */
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .login-container h3 {
            text-align: center;
            color: rgb(67, 133, 105); /* Title color */
        }
        .login-container input {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-container button {
            width: 100%;
            padding: 10px;
            background-color: rgb(67, 133, 105); /* Button color */
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .login-container button:hover {
            background-color: rgb(50, 105, 80); /* Darker shade on hover */
        }
        .login-container p {
            text-align: center;
        }
        footer {
            background-color: rgb(67, 133, 105); /* Footer color */
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
    <script>
        function toggleForms() {
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerForm');
            loginForm.style.display = loginForm.style.display === 'none' ? 'block' : 'none';
            registerForm.style.display = registerForm.style.display === 'none' ? 'block' : 'none';
        }
    </script>
</head>
<body>
    <header>
        <h1>Gym Website</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="login-container">
            <div id="loginForm">
                <h3>Sign In</h3>
                <form method="POST">
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" name="login">Login</button>
                </form>
                <p><?php if ($error) echo "<span style='color:red;'>$error</span>"; ?></p>
                <p>Don't have an account? <a href="javascript:void(0);" onclick="toggleForms()">Sign Up</a></p>
            </div>

            <div id="registerForm" style="display:none;">
                <h3>Sign Up</h3>
                <form method="POST">
                    <input type="text" name="reg_username" placeholder="Username" required>
                    <input type="password" name="reg_password" placeholder="Password" required>
                    <input type="email" name="reg_email" placeholder="Email" required>
                    <button type="submit" name="register">Register</button>
                </form>
                <p><?php if ($success) echo "<span style='color:green;'>$success</span>"; ?></p>
                <p>Already have an account? <a href="javascript:void(0);" onclick="toggleForms()">Sign In</a></p>
            </div>
        </div>
    </main>
    <footer>
        <p>&copy; 2025 Gym Website. All rights reserved.</p>
    </footer>
</body>
</html>