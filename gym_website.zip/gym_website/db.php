<?php
$host = 'localhost';
$db = 'gym_website';
$user = 'root'; // Change this if your MySQL username is different
$pass = ''; // Change this if you have a password

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>