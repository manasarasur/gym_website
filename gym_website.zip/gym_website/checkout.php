<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if the cart is empty
if (empty($_SESSION['cart'])) {
    header("Location: cart.php"); // Redirect to cart if empty
    exit();
}
$total_price = 0;
foreach ($_SESSION['cart'] as $product_id => $quantity) {
    $stmt = $pdo->prepare("SELECT price FROM products WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();
    if ($product) {
        $total_price += $product['price'] * $quantity;
    }
}

// Handle order placement
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $address = $_POST['address'];
    $phone = $_POST['phone'];
    $pincode = $_POST['pincode'];
    $description = $_POST['description'];
    $state = $_POST['state'];
    $floor = $_POST['floor'];
    $area = $_POST['area'];
    $payment_method = $_POST['payment_method'];
    // Here you would typically save the order details to the database
    // For demonstration, we'll just clear the cart and show a success message
    $_SESSION['cart'] = []; // Clear the cart

    echo "<script>alert('Order successfully placed!'); window.location.href='index.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background: #4CAF50; /* Green */
            color: #fff;
            padding: 10px 0;
            text-align: center;
        }
        nav ul {
            list-style: none;
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin: 0 15px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        main {
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }
        form {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 100%;
            max-width: 500px;
        }
        h2 {
            color: #4CAF50; /* Green */
            margin-bottom: 15px;
            text-align: center;
        }
        input[type="text"], input[type="number"], textarea, select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }
        input[type="text"]:focus, input[type="number"]:focus, select:focus {
            border-color: #4CAF50; /* Green */
        }
        button {
            background-color: #4CAF50; /* Green */
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049; /* Darker green on hover */
        }
        footer {
            text-align: center;
            padding: 10px 0;
            background: #333;
            color: #fff;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        .description {
            height: 80px; /* Set a fixed height for the description textarea */
        }
        .total-price {
            font-size: 18px;
            color:rgb(75, 145, 78); /* Green */
            margin: 10px 0;
            text-align: center;
        }
    </style>
</head>
<body>
    <header>
        <h1>Checkout</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="cart.php">Your Cart</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <form action="checkout.php" method="POST">
            <h2>Billing Information</h2>
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="text" name="phone" placeholder="Phone Number" required>
            <input type="text" name="address" placeholder="Address" required>
            <input type="text" name="area" placeholder="Area" required>
            <input type="text" name="floor" placeholder="Floor (optional)">
            <input type="text" name="pincode" placeholder="Pincode" required>
            <input type="text" name="state" placeholder="State" required>
            <textarea name="description" placeholder="Description (optional)"></textarea>
            
            <h2>Total Price</h2>
            <div class="total-price">$<?php echo number_format($total_price, 2); ?></div>

            <h2>Payment Method</h2>
            <select name="payment_method" required>
                <option value="cod">Cash on Delivery</option>
                <option value="credit_card">Credit Card</option>
                <option value="debit_card">Debit Card</option>
                <option value="paypal">PayPal</option>
            </select>

            <button type="submit">Place Order</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2025 Gym Website. All rights reserved.</p>
    </footer>
</body>
</html>