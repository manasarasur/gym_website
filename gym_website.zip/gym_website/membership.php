<?php
session_start();
include 'db.php'; // Include your database connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Fetch membership plans from the database
$stmt = $pdo->prepare("SELECT * FROM membership_plans");
$stmt->execute();
$plans = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Initialize a variable for the success message
$successMessage = "";

// Handle membership form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $plan_id = $_POST['plan_id']; // Get selected plan ID

    // Insert membership data into the database
    $stmt = $pdo->prepare("INSERT INTO memberships (name, email, phone, plan_id) VALUES (?, ?, ?, ?)");
    if ($stmt->execute([$name, $email, $phone, $plan_id])) {
        $successMessage = "Membership successfully purchased!";
    } else {
        $successMessage = "There was an error processing your request.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Membership</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            background-color: #F4F4F4; /* Light gray */
            margin: 0;
            padding: 0;
        }
        header {
            background-color: rgb(67, 133, 105); /* Main header color */
            color: #fff;
            padding: 20px;
            text-align: center;
        }
        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        nav ul li {
            display: inline;
            margin: 0 15px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        main {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff; /* White background for the form */
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: rgb(67, 133, 105); /* Button color */
            color: #fff;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: rgb(50, 105, 80); /* Darker shade on hover */
        }
        footer {
            background-color: rgb(67, 133, 105); /* Footer color */
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
        .success-message {
            color: green;
            font-weight: bold;
            text-align: center;
            margin: 20px 0;
        }
    </style>
</head>
<body>
    <header>
        <h1>Get Your Membership</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="booking.php">Book Your Slot</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <?php if ($successMessage): ?>
            <div class="success-message"><?php echo $successMessage; ?></div>
        <?php endif; ?>
        <form action="membership.php" method="POST">
            <input type="text" name="name" placeholder="Your Name" required>
            <input type="email" name="email" placeholder="Your Email" required>
            <input type="text" name="phone" placeholder="Your Phone Number" required>
            
            <label for="plan">Select Membership Plan:</label>
            <select name="plan_id" required>
                <option value="">-- Select a Plan --</option>
                <?php foreach ($plans as $plan): ?>
                    <option value="<?php echo $plan['id']; ?>">
                        <?php echo $plan['plan_name'] . ' - $' . number_format($plan['cost'], 2); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            
            <button type="submit">Get Membership</button>
        </form>
    </main>
    <footer>
        <p>&copy; 2025 Gym Website. All rights reserved.</p>
    </footer>
</body>
</html>