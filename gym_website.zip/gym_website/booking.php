<?php
session_start();
include 'db.php'; // Include your database connection file

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Handle booking form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $date = $_POST['date'];
    $time = $_POST['time'];
    $name = $_POST['name'];

    // Insert booking data into the database
    $stmt = $pdo->prepare("INSERT INTO bookings (name, date, time) VALUES (?, ?, ?)");
    $stmt->execute([$name, $date, $time]);

    echo "<script>alert('Slot booked successfully!');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Your Slot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e0f7fa; /* Light teal background */
            color: #004d40; /* Dark teal text */
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #00796b; /* Teal header */
            color: white;
            padding: 20px;
            text-align: center;
        }

        nav ul {
            list-style-type: none;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin: 0 15px;
        }

        nav ul li a {
            color: white;
            text-decoration: none;
        }

        nav ul li a:hover {
            text-decoration: underline;
        }

        main {
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 150px); /* Adjust height based on header and footer */
        }

        .form-container {
            background-color: #ffffff; /* White background for form */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 20px;
            width: 300px;
        }

        h2 {
            color: #00796b; /* Teal color for headings */
        }

        label {
            display: block;
            margin: 10px 0 5px;
        }

        input[type="date"],
        input[type="time"],
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #00796b; /* Teal border */
            border-radius: 4px;
        }

        button {
            background-color: #00796b; /* Teal button */
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #004d40; /* Darker teal on hover */
        }

        footer {
            background-color: #00796b; /* Teal footer */
            color: white;
            text-align: center;
            padding: 10px;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <h1>Book Your Slot</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="products.php">Products</a></li>
                <li><a href="membership.php">Get Membership</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <div class="form-container">
            <form action="booking.php" method="POST">
                <h2>Booking Form</h2>
                <label for="date">Select Date:</label>
                <input type="date" name="date" required>
                
                <label for="time">Select Time:</label>
                <input type="time" name="time" required>
                
                <label for="name">Your Name:</label>
                <input type="text" name="name" placeholder="Your Name" required>
                
                <button type="submit">Book Slot</button>
            </ form>
        </div>
    </main>
    <footer>
        <p>&copy; 2025 Gym Website. All rights reserved.</p>
    </footer>
</body>
</html>