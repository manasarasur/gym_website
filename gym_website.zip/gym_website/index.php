<?php
session_start();
include 'db.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Our Gym</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Open Sans', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #F4F4F4; /* Light gray */
        }
        header h1 {
    margin-bottom: 20px; /* Adjust the value to increase or decrease space */
}

nav ul {
    list-style: none; /* Remove bullet points */
    padding: 0; /* Remove default padding */
    margin: 0; /* Remove default margin */
    display: flex; /* Use flexbox to align items horizontally */
    justify-content: center; /* Center the items */
}

nav ul li {
    margin: 0 15px; /* Add space between items */
}

nav ul li a {
    text-decoration: none; /* Remove underline from links */
    color: #fff; /* Change link color to white */
    font-size: 18px; /* Adjust font size as needed */
}
        .hero {
            background-image: url('https://i.pinimg.com/736x/ca/3b/00/ca3b003ff8d2f061daa460f19d310beb.jpg'); /* Replace with your gym image */
            background-size: cover;
            background-position: center;
            height: 600px;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #fff;
            text-align: center;
        }
        .hero h1 {
            font-size: 48px;
            margin: 0;
        }
        .cta-button {
            background-color: #F7DC6F; /* Bright yellow */
            color: #2E4053; /* Deep blue */
            padding: 15px 30px;
            border: none;
            border-radius: 5px;
            font-size: 20px;
            cursor: pointer;
            text-decoration: none;
            margin-top: 20px;
        }
        .services {
            padding: 40px;
            text-align: center;
        }
        .services h2 {
            font-size: 36px;
            color:rgb(6, 6, 7); /* Deep blue */
        }
        .testimonial {
            background-color:rgb(67, 133, 105); /* Light blue */
            color: #fff;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
        }
        footer {
            background-color: #2E4053; /* Deep blue */
            color: #fff;
            text-align: center;
            padding: 10px 0;
            position: relative;
            bottom: 0;
            width: 100%;
        }
    </style>
</head>
<body>

<header>
    <h1>Welcome to Our Gym</h1>
    <nav>
        <ul>
            <h1><li><a href="products.php">Products</a></li></h1>
            <h1><li><a href="membership.php">Membership</a></li></h1>
            <h1><li><a href="booking.php">Book your slot</a></li></h1>
            <h1> <li><a href="cart.php">Cart</a></li></h1>
            <h1><li><a href="logout.php">Logout</a></li></h1>

        </ul>
    </nav>
</header>

<div class="hero">
    <h1>Transform Your Body, Transform Your Life</h1>
   
</div>

<div class="services">
    
    <p>We offer a variety of fitness classes, personal training, and state-of-the-art equipment to help you achieve your fitness goals.</p>
    <div class="testimonial">
        <p>"This gym has changed my life! The trainers are amazing and the community is so supportive!" - Happy Member</p>
    </div>
</div>



<footer>
    <p>&copy; 2025 Our Gym. All rights reserved.</p>
</footer>

</body>
</html>